<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Questions Page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel = "stylesheet" type = "text/css" href = "<?php echo base_url(); ?>css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<style>

	th,td{
		color:antiquewhite;
		padding:10px 15px;
		font-family: Schadow BT;
		letter-spacing:0.9px;
		text-transform:capitalize;
	}
</style>
</head>  

<body>

<div class = "container-fluid">
	<br>
		<label class = "l1">Answered Questions</label> <br><br>
		<table>
		
		<tr>
			<th>Sr.No</th>
			<th>Questions</th>
			<th>Date & Time </th>
			<th>Answer</th>
		
		</tr>
		
		
		<?php 
		foreach($user_data2 as $row2 => $value2)
		{
			
		
		?>
		
		<tr>
			<td><?php echo $value2["id"];?></td>
			<td><?php echo $value2["question"];?></td>
			<td><?php echo $value2["ts"];?></td>
			<td><?php echo $value2["answer"];?></td>
		
		</tr>
		
		<?php
		
		}
		?>
		
		</table>
		
		
</div>

<br><br>
</body>
</html>