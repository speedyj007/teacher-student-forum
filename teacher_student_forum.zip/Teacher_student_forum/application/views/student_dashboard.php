<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Student Dashboard</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel = "stylesheet" type = "text/css" href = "<?php echo base_url(); ?>css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  
    <style>
  
  sup{
  color: #211b2d;
    font-family: Schadow BT;
    font-weight: 900;
    border: 2px solid darkmagenta;
    padding: 2px 3px;
    border-radius: 50%;
	
  </style>
</head>
<body>

	<div class = "container-fluid">
	<br>
	
	<h1 class = "forum_name" >Student & Teachers Forum</h1>
		<hr class = "hr1">
		
	<div class = "adding_header">
			
			<h3 class = "adding_heading" ><u>Student</u> <u>Dashboard</u></h3>
			
	</div>
	
	<div class = "login_form">

		<a href = "<?php echo base_url().'Student_controller/add_questions' ?>"  target = '_blank' class = "btn btn-primary" >Ask Questions</a><br><br>
		<a href = "<?php echo base_url().'Student_controller/views_qts' ?>" target = '_blank' class = "btn btn-primary" >Notifications </a><br><br>
		
		</div>	
	
	</div>

	<?php
	if(isset($_SESSION["inserted"] ) )
	{
		echo "alert('Student Successfully Added')";
	}
	
	?>
	
</body>
</html>