<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Add Students</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel = "stylesheet" type = "text/css" href = "<?php echo base_url(); ?>css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  
  
  <style>
  .t1{
	  margin-bottom:24px;
  }
  </style>
  
  </head>
  
  
  <body>
  <div class = "container-fluid">
	<br>
	
	<h1 class = "forum_name" >Student & Teachers Forum</h1>
		<hr class = "hr1">
	
	<div class = "adding_header">
			
			<h3 class = "adding_heading" ><u>Add</u> <u>Students</u></h3>
			
			</div>
  
  <?php echo validation_errors("<div class = 'alert alert-danger'>","</div>"); ?>
  <br>
	
	
	<div class = "login_form">
		
	<form  method = "post" action = "<?php echo base_url().'teacher_controller/add_data'; ?>">
	
	<label class = "l1">Student Name : </label> <br>
	<input type = "text" class = "t1" placeholder ="" name = "name" autocomplete = "off"><br><br>
	
	<label class = "l1">Email Id : </label> <br>
	<input type = "email" class = "t1" placeholder ="" name = "email" autocomplete = "off"><br><br>	
	
	<label class = "l1">Password : </label> <br>
	<input type = "password" class = "t1" placeholder ="" name = "password" autocomplete = "off"><br><br>

	<input type = "submit" class = "btn btn-primary" value = "Add Student">	
			
	</form>
	
	</div>
  
  </div>
  
  <script>
	
	<?php
	if(isset($_SESSION['inserted'] ) )
	{
		echo "alert( 'Student Added Successfully!!!')";
	}
  
?>
  </script>
  
  </body>
  </html>