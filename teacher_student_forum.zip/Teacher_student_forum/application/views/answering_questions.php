<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Teachers Dashboard</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel = "stylesheet" type = "text/css" href = "<?php echo base_url(); ?>css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<style>
input{
	background: none;
    border: none;
    color: aliceblue;
	outline:none;
	
}

</style>
</head>  
  <body>
	
	<div class = "container-fluid">
	<br>
	
	<h1 class = "forum_name" >Student & Teachers Forum</h1>
		<hr class = "hr1">
  
		<div class = "adding_header">
			
			<h3 class = "adding_heading" ><u>Answer</u> <u>Questions</u></h3>
			
		</div>
		
		<form  method = "post" action = "<?php echo base_url(). 'answered/edit_qts'; ?>">
		<br>
		
		
		<input type = "hidden" name = 'id' value = "<?php echo $query[0]['id']; ?>">
		
		<label class = "l1" name = "<?php $query[0]['id']; ?>" >
		
		<input type = "text" name = "question" value = "Question No : <?php echo $query[0]['id']; ?>" readonly>
		 </label> <br>
		
		
		<label class = "l1"><?php echo $query[0]['question']; ?></label> <br><br>
		<textarea style = "width:50%;height:200px; border:2px solid #0DB8DE;" name = "answer" placeholder = "" class = "t1" required></textarea><br><br>
		
		<input type = "submit" class = "btn btn-primary" value = "Submit"> &nbsp;
		<input type = "reset" class = "btn btn-warning" value = "Clear">
		
		<br><br><br><br> 
				</form>
		
</body>
</html>		