<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Questions Page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel = "stylesheet" type = "text/css" href = "<?php echo base_url(); ?>css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<style>

	th,td{
		color:antiquewhite;
		padding:10px 15px;
		font-family: Schadow BT;
		letter-spacing:0.9px;
		text-transform:capitalize;
	}
	
	.hr2{
		border: 1px solid #5f5f9a;
	}
	a{
		color:antiquewhite !important;
		text-decoration:none !important;
	}
</style>
</head>  

<body>

<div class = "container-fluid">
	<br>
	
	<h1 class = "forum_name" >Student & Teachers Forum</h1>
		<hr class = "hr1">
  
		<div class = "adding_header">
			
			<h3 class = "adding_heading" ><u>Questionaire</u> <u>Page</u></h3>
			
		</div>
		<br><br>
		<label class = "l1">Un-Answered Questions</label> <br><br>
		<table>
		
		<tr>
			<th>Sr.No</th>
			<th>Questions</th>
			<th>Date & Time </th>
			<th>Answered</th>
			<th>Options</th>
		</tr>
		
		
		<?php 
		foreach($user_data as $row => $value)
		{
			$id = $value["id"];
		
		?>
		
		<tr>
			<td><?php echo $id;?></td>
			<td><?php echo $value["question"];?></td>
			<td><?php echo $value["ts"];?></td>
			<td><?php echo $value["answer"];?></td>
			<td class = 'btn btn-primary' ><a href = "<?php echo base_url().'answered/index/'.$id ?> " target = '_blank' ><?php $id; ?> Answer</a></td>
		
		</tr>
		
		<?php
		
		}
		?>
		
		</table>
		<br><br>
		<hr class = "hr2">
		
		
</div>

	<script>
		<?php 
			if(isset($_SESSION["updated"] ) )
			{
				
				if($_SESSION["updated"] == "yes")
				{
					
					echo "alert('Answer is post !!!')";
					
				}
				else if($_SESSION["updated"] == "no")
				{
					echo "alert('some error occured !!!')";
				}
				
			}
		?>
	
	</script>

</body>
</html>