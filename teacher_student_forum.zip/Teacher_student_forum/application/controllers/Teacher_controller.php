<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Teacher_controller extends CI_Controller {
	
	
	function add_student()
	{
		$this->load->database();
		$this->load->library('form_validation');
		$this->load->helper('form');
		
		
		 $this->form_validation->set_rules("name", "Name", "required|alpha");
		 $this->form_validation->set_rules("email", "Email id", "required|valid_email");
		 
		 
		$this->load->view("adding_student");  
				
		 
             
 				
	}
	
	
	function view_controller()
	{
				$this->load->model("teacher_questions");
				$user_array["user_data"] = $this->teacher_questions->return_users();
				$this->load->view("qestionaire_page",$user_array);  
				
				
				$this->load->model("answered");
				$user_array2["user_data2"] = $this->answered->return_users2();
				 $this->load->view("answered_question",$user_array2);  
 				
	}
	
	
	function add_data()
	{
		
		$this->load->database();
		$this->load->library('form_validation');
		$this->load->helper('form');
		
		
		 $this->form_validation->set_rules("name", "Name", "required|alpha_numeric_spaces");
		 $this->form_validation->set_rules("email", "Email id", "required|valid_email");
		 
		 
            if ($this->form_validation->run() == FALSE)
             {
                $this->load->view('adding_student');
             }
			 
			 
			 else{
				 
				 $name  = $_POST["name"];
				 $email = $_POST["email"];
				 $dist  = 1;
				 $pass  = $_POST["password"];
				 
				 
				 $query = $this->db->query("insert into qts_entry(name, email, dist, password) values('$name', '$email', '$dist', '$pass' )");
				 
				 if($query)
				 {
					 
					 $this->session->set_flashdata('inserted', 'yes');
					 redirect("Teacher_controller/add_student");
					 
				 }
				
			 }
	}	
	
	
}


?>