<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Answered extends CI_Controller {


	function index($id)
	{
		print_r($id);
		
		$query = $this->db->query("select * from qts where id = '$id' ");
		$data['query'] = $query->result_array(); 
		$this->load->view("answering_questions",$data);   
	}
	
	function edit_qts()
	{
		/* print_r($_POST); */
		
		/* $question = $_POST["question"]; */
		$answer   = $_POST["answer"];
		$qts_id   = $_POST["id"];
		$ts       = date("Y-m-d H:i:s");
		
		
		
		$answer = $this->db->query("update qts set answer = '$answer', ts = '$ts' where id = '$qts_id' ");
		
		if($answer)
				 {
					 
					 $this->session->set_flashdata('updated', 'yes');
					 redirect("Teacher_controller/view_controller");
					 
				 }
				 
		else{
					 $this->session->set_flashdata('updated', 'no');
					 redirect("Teacher_controller/view_controller");
		}	  
			
		
	}
	
	
}
	?>