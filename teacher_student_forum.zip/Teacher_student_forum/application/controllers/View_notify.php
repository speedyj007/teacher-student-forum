<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class View_notify extends CI_Controller {
	
	
	function views_qts()
	{
				$this->load->model("teacher_questions");
				$user_array["user_data"] = $this->teacher_questions->return_users();
				$this->load->view("qestionaire_page",$user_array);  
				
				
 				$this->load->model("answered");
				$user_array2["user_data2"] = $this->answered->return_users2();
				 $this->load->view("answered_question",$user_array2);  
	}
	

	
}


?>