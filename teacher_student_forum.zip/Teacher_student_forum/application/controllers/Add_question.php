<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Add_question extends CI_Controller {
	
	
	function add_questions()
	{
		$this->load->view('questions_ask');
	}
	
	/* function add_forum_qts()
	{
		print_r($_POST);
		
	} */
	
	
}


?>