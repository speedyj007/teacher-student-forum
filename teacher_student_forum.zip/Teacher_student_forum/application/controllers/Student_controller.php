<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Student_controller extends CI_Controller {
	
	function add_questions()
	{
		$this->load->database();
		$this->load->library('form_validation');
		$this->load->helper('form');
		
		$this->form_validation->set_rules("question", "Question", "trim|required|alpha_numeric_spaces");
		
		$this->load->view('questions_ask');
	}
	
	
	function views_qts()
	{
				$this->load->model("student_questions");
				$user_array["user_data"] = $this->student_questions->return_users();
				$this->load->view("student_questions_section",$user_array);  
				
				
 				$this->load->model("answered");
				$user_array2["user_data2"] = $this->answered->return_users2();
				$this->load->view("answered_question",$user_array2);  
	}
	
	function add_qts()
	{
		
		$this->load->database();
		$this->load->library('form_validation');
		$this->load->helper('form');
		
		$this->form_validation->set_rules("question", "Question", "trim|required");
		
		 if ($this->form_validation->run() == FALSE)
             {
                $this->load->view('adding_student');
             }
		
		else{
			
			$question = $_POST["question"];
			$answer   = "Not Yet";
			
			$query = $this->db->query("insert into qts(question, answer) values('$question', '$answer')");
			
			 if($query)
				 {
					 
					 $this->session->set_flashdata('inserted', 'yes');
					 redirect("Student_controller/add_questions");
					 
				 }
			
		}
	}
}
?>