<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends CI_Controller {


	public function index()
	{
		$this->load->database();
		 $this->load->library('form_validation');
		 $this->load->helper('form');
		
		
		
		 $this->form_validation->set_rules("email", "Email id", "required|valid_email");
		 $this->form_validation->set_rules("password", "Password", "required|alpha_numeric");
		 
            if ($this->form_validation->run() == FALSE)
             {
                $this->load->view('login');
             }
             else
             {
				 
				
				if(isset($_POST) )
				{
								
				$email = $_POST["email"];
				$pass  = $_POST["password"];	
				
				$query = $this->db->query("select * from qts_entry where email = '$email' and password = '$pass' ");
				
				if($query->num_rows() )
				{
					
					$result = $query->result_array();
					
					$this->session->set_userdata('user_id', $result[0]["id"] );
					
					if($result[0]["dist"] == 0)
					{
					
					$this->load->model("notify");
					$data["query"] = $this->notify->return_users(); 
					$this->load->view('teacher_dashboard',$data);   
					}
					
					else{
						
						$this->load->model("notify");
					$data["query"] = $this->notify->return_users(); 
					$this->load->view('student_dashboard',$data);   
					}
				}
				else{
					$this->session->set_flashdata('error', 'Invalid login details !!!!');
					redirect("test/index");
				}
					
				}
					
				else{
					
					die("Invalid login details !!!!");
				}	
					 /* $this->load->view('student_dashboard'); */
			
             }
				
			
	}
	
				function log_out()
				{
					session_destroy();
					redirect("test/index");
				}
		
	
}
