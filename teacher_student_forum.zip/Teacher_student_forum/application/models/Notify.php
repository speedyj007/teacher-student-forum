<?php

class Notify extends CI_Model{
	
	function return_users()
	
	{
		$this->load->database();
		$this->db->select(" * ");
		$this->db->from("qts");
		$this->db->like("answer", "Not Yet ");
		return $this->db->count_all_results();
		
	}
	
}