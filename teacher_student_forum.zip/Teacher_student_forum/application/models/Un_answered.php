<?php

class Un_answered extends CI_Model{
	
function un_ans($id)
		{
			
			$this->load->database();
			$query = $this->db->query("select * from qts where id = '$id' ");
			$query->result_array();
			
			return $query->result_array();
			
		}
}

?>