<?php

class Answered extends CI_Model{
	
function return_users2()
		{
			$this->load->database();
			$query = $this->db->query("select * from qts where answer not like 'Not Yet' order by ts desc");
			$query->result_array();
			
			return $query->result_array();
		}
		
}
?>