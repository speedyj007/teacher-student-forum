<?php

class Teacher_questions extends CI_Model{
		
		function return_users()
		{
			$this->load->database();
			$query = $this->db->query("select * from qts where answer like 'Not Yet' order by ts desc");
			$query->result_array();
			
			return $query->result_array();
		}
		
	
		
	}


?>